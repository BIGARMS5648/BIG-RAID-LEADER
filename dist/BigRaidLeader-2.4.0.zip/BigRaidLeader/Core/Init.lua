-- BIG RAID LEADER - 초기화 / 슬래시 명령 (TOC 마지막에 로드)
local ADDON_NAME, BRL = ...
local U, API, Money = BRL.Util, BRL.API, BRL.Money

local Init = {}
BRL.Init = Init

local function onAddonLoaded(_, _, name)
    if name ~= ADDON_NAME then return end
    BRL.DB:Init()
    BRL.Migration:Run(BRL.db)
    if not next(BRL.acct.buffs.required) then
        for k, v in pairs(BRL.Data.DefaultRequiredBuffs) do BRL.acct.buffs.required[k] = v end
    end
    BRL:InitializeModules()
    BRL.Events:Unregister("ADDON_LOADED", Init)
end

local function onLogin()
    BRL.DB:RebindCharacter()
    BRL.Perm:OnEnable()
    BRL:EnableModules()
    BRL.Migration:AutoBackup()
    BRL.Events:Register("PLAYER_REGEN_DISABLED", Init, function() BRL.Events:Fire(BRL.Events.MSG.COMBAT_CHANGED, true) end)
    BRL.Events:Register("PLAYER_REGEN_ENABLED", Init, function() BRL.Events:Fire(BRL.Events.MSG.COMBAT_CHANGED, false) end)
    local iface = API.GetInterfaceVersion()
    BRL:Print("v%s 로드됨 - |cffffffff/brl|r 로 창을 엽니다. (Interface %s)", BRL.VERSION, tostring(iface or "?"))
end

BRL.Events:Register("ADDON_LOADED", Init, onAddonLoaded)
BRL.Events:Register("PLAYER_LOGIN", Init, onLogin)

---------------------------------------------------------------------------
-- 슬래시 명령: /brl
---------------------------------------------------------------------------
local HELP = {
    "|cffffd100BIG RAID LEADER|r 명령어",
    "/brl - 메인 창 열기/닫기",
    "/brl <메뉴> - 메뉴 바로 열기 (대시보드, 모집, 공대원, 편성, 역할, 준비, 버프, 야영지, 지휘, 공략, 경매, 거래, 장부, 정산, 설정)",
    "/brl 경매 [아이템링크] [시작가] - 경매 등록",
    "/brl 입찰 <이름> <금액> - 진행 중 경매에 수동 입찰",
    "/brl 카운트 - 경매 카운트(5초) / /brl 카운트취소 - 카운트 취소",
    "/brl 준비 - 준비 확인 / /brl 풀 [초] - 풀링 카운트다운",
    "/brl 전투준비 - 도핑(음식/영약/비약) 점검 / /brl 구성 [20|40] - 구성 분석·추천 직업",
    "/brl 세션 [이름] - 새 공격대 세션",
    "/brl 백업 - 데이터 백업 / /brl 진단 - 자가 진단 (API·무결성·오류 기록, 문제 보고용)",
    "/brl 추적 - 최근 거래 이벤트 추적",
    "/brl hud - 공대장 HUD 열기/닫기 / /brl 판정 - 풀링 판정",
    "/brl 복구 - 전멸 복구 점검 (사망자·영혼석·재버프·도핑) / /brl 보스준비 - 현재 보스 준비 적용",
}

local PAGE_ALIASES = {
    ["대시보드"] = "dashboard", dashboard = "dashboard", dash = "dashboard",
    ["모집"] = "recruit", recruit = "recruit",
    ["공대원"] = "roster", roster = "roster",
    ["편성"] = "groups", ["파티"] = "groups", groups = "groups",
    ["역할"] = "roles", roles = "roles",
    ["준비"] = "ready", ready = "ready",
    ["버프"] = "buffs", buffs = "buffs", ["야영지"] = "camps",
    ["지휘"] = "command", command = "command",
    ["공략"] = "boss", boss = "boss",
    ["경매"] = "auction", auction = "auction",
    ["거래"] = "trades", trades = "trades", trade = "trades",
    ["장부"] = "ledger", ledger = "ledger",
    ["정산"] = "settlement", settlement = "settlement",
    ["설정"] = "settings", settings = "settings", config = "settings",
}

function Init:Slash(msg)
    msg = U.Trim(msg or "")
    if msg == "" then
        if BRL.UI then BRL.UI:Toggle() end
        return
    end
    local cmd, rest = msg:match("^(%S+)%s*(.-)$")
    local lower = cmd:lower()
    if lower == "help" or cmd == "도움말" or cmd == "?" then
        for _, l in ipairs(HELP) do BRL:Print(l) end
        return
    end
    if cmd == "카운트" or lower == "count" then
        local ok, err = BRL.Auctions:StartCount()
        if not ok then BRL:Print(tostring(err)) end
        return
    end
    if cmd == "카운트취소" or lower == "countcancel" then
        local ok, err = BRL.Auctions:CancelCount(nil, "manual")
        if not ok then BRL:Print(tostring(err)) end
        return
    end
    if cmd == "전투준비" or cmd == "도핑" or lower == "prep" then
        BRL.CombatPrep:Run()
        return
    end
    if cmd == "구성" or lower == "comp" then
        for _, l in ipairs(BRL.Composition:Lines(BRL.Composition:Analyze(tonumber(rest)))) do BRL:Print(l) end
        return
    end
    if cmd == "준비" and rest == "" then
        if BRL.Perm:Require("raid.command") then BRL.Command:ReadyCheck() end
        return
    end
    if cmd == "풀" or lower == "pull" then
        -- 풀링 판정이 보류면 확인 창을 거친다 (대시보드/지휘/HUD 와 동일)
        if BRL.Perm:Require("raid.command") then BRL.UIActions.PullWithCheck(tonumber(rest) or BRL.acct.command.pullSeconds) end
        return
    end
    if cmd == "경매" and rest ~= "" then
        local link = rest:match("(|c%x+|H.-|h|r)") or rest:match("(|H.-|h)")
        if not link then BRL:Print("아이템 링크를 함께 입력하세요 (Shift+클릭).") return end
        local after = rest:gsub(link:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1"), "")
        local price = Money.Parse(U.Trim(after))
        local auc, err = BRL.Auctions:Add(link, { startPrice = price })
        if auc then BRL:Print("경매 등록: %s", link) else BRL:Print("경매 등록 실패: %s", tostring(err == "duplicate" and "이미 등록된 아이템" or err)) end
        return
    end
    if cmd == "입찰" or lower == "bid" then
        local name, amountText = rest:match("^(%S+)%s+(.+)$")
        local auc = BRL.Auctions:GetActive()
        local amount = amountText and Money.Parse(amountText)
        if not auc then BRL:Print("진행 중인 경매가 없습니다.") return end
        if not name or not amount then BRL:Print("사용법: /brl 입찰 <이름> <금액>") return end
        local bid, why = BRL.Bids:Place(auc.id, name, amount, "manual")
        if bid and bid.accepted then BRL:Print("입찰 등록: %s %s", name, Money.Format(amount))
        else BRL:Print("입찰 거부: %s", tostring(why)) end
        return
    end
    if cmd == "세션" or lower == "session" then
        local s = BRL.Session:Create({ name = rest ~= "" and rest or nil })
        if s then BRL:Print("새 공격대 세션: %s", s.name) end
        return
    end
    if cmd == "백업" or lower == "backup" then
        local b = BRL.Migration:CreateBackup("수동 백업 (/brl 백업)")
        if b then BRL:Print("백업 완료 (%s바이트, 체크섬 %d)", U.FormatNumber(b.size), b.checksum) end
        return
    end
    if lower == "hud" or cmd == "허드" then
        BRL.HUD:Toggle()
        return
    end
    if cmd == "판정" or lower == "pullcheck" then
        for _, l in ipairs(BRL.CombatPrep:PullCheckLines()) do BRL:Print(l) end
        return
    end
    if cmd == "복구" or lower == "wipe" then
        BRL.CombatPrep:WipeRecovery()
        return
    end
    if cmd == "보스준비" or lower == "bossprep" then
        local key = BRL.RaidProgress:GetCurrentBoss()
        if not key then BRL:Print("현재 보스가 없습니다. 공략 화면에서 보스를 선택해 [준비 적용]을 누르세요.") return end
        if BRL.UIActions then BRL.UIActions.ApplyBossPrep(key) end
        return
    end
    if cmd == "진단" or lower == "diag" or cmd == "검사" or lower == "validate" or cmd == "호환성" or lower == "compat" then
        BRL.Diagnostics:Show()
        return
    end
    if cmd == "추적" or lower == "trace" then
        if BRL.UIActions then BRL.UIActions.TradeTraces() end
        return
    end
    if lower == "debug" then
        BRL.acct.debug = not BRL.acct.debug
        BRL:Print("디버그: %s", BRL.acct.debug and "켜짐" or "꺼짐")
        return
    end
    local page = PAGE_ALIASES[cmd] or PAGE_ALIASES[lower]
    if page and BRL.UI then
        BRL.UI:Open(page)
        return
    end
    for _, l in ipairs(HELP) do BRL:Print(l) end
end

_G.SLASH_BIGRAIDLEADER1 = "/brl"
_G.SLASH_BIGRAIDLEADER2 = "/bigraidleader"
_G.SLASH_BIGRAIDLEADER3 = "/빅레이드"
if _G.SlashCmdList then
    _G.SlashCmdList.BIGRAIDLEADER = function(msg) Init:Slash(msg) end
end

-- 키 바인딩 이름
_G.BINDING_HEADER_BIGRAIDLEADER = "BIG RAID LEADER"
_G.BINDING_NAME_BRL_TOGGLE = "메인 창 열기/닫기"
_G.BINDING_NAME_BRL_READYCHECK = "준비 확인"
_G.BINDING_NAME_BRL_PULL = "풀링 카운트다운"
_G.BINDING_NAME_BRL_CANCELPULL = "풀링 취소"
_G.BINDING_NAME_BRL_AUCTION = "경매 화면 열기"
_G.BINDING_NAME_BRL_COMBATPREP = "전투 준비 (도핑 점검)"
_G.BINDING_NAME_BRL_AUCTIONCOUNT = "경매 카운트"
_G.BINDING_NAME_BRL_AUCTIONCOUNTCANCEL = "경매 카운트 취소"
_G.BINDING_NAME_BRL_HUD = "공대장 HUD 열기/닫기"
_G.BINDING_NAME_BRL_PULLCHECK = "풀링 판정"

function _G.BigRaidLeader_Binding(action)
    if action == "READY" then
        if BRL.Perm:Require("raid.command") then BRL.Command:ReadyCheck() end
    elseif action == "PULL" then
        if BRL.Perm:Require("raid.command") then BRL.UIActions.PullWithCheck(BRL.acct.command.pullSeconds) end
    elseif action == "CANCELPULL" then
        if BRL.Perm:Require("raid.command") then BRL.Command:CancelPull() end
    elseif action == "COUNT" then
        local ok, err = BRL.Auctions:StartCount()
        if not ok then BRL:Print(tostring(err)) end
    elseif action == "COUNTCANCEL" then
        local ok, err = BRL.Auctions:CancelCount(nil, "manual")
        if not ok then BRL:Print(tostring(err)) end
    elseif action == "PREP" then
        BRL.CombatPrep:Run()
    elseif action == "AUCTION" then
        if BRL.UI then BRL.UI:Open("auction") end
    elseif action == "HUD" then
        BRL.HUD:Toggle()
    elseif action == "PULLCHECK" then
        if BRL.UIActions then BRL.UIActions.ShowPullCheck() end
    end
end
